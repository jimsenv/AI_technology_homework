clc; clear all;

disp("请输入棋盘大小")
n = str2double(input('s', 's'));
board = zeros(n);
solutions = {};

solutions = solveNQueens(board, 1, solutions);

numSolutions = length(solutions);
fprintf('此情况下解的数量为：%d\n', numSolutions);

while numSolutions > 0
    disp("需要展示第几个解？");
    solutionIndex = str2double(input('s', 's'));
    
    if solutionIndex==-1
        break;
    end
    
    if solutionIndex >= 1 && solutionIndex <= numSolutions
        figure;
        hold on;
        axis([1 n+1 1 n+1]);
        set(gca, 'xtick', [], 'ytick', [], 'xcolor', 'w', 'ycolor', 'w');
        for i = 1:n
            for j = 1:n
                rectangle('Position', [j, n-i+1, 1, 1], 'EdgeColor', 'k', 'LineWidth', 2);
                if solutions{solutionIndex}(i, j) == 1
                    text(j+0.5, n-i+1.5, 'Q', 'FontSize', 18, 'HorizontalAlignment', 'center');
                end
            end
        end
        hold off;
    else
        disp('输入的解编号不正确');
    end

end

function solutions = solveNQueens(board, col, solutions)
    n = size(board, 1);

    if col > n
        solutions{end + 1} = board;
        return;
    end

    for i = 1:n
        if isSafe(board, i, col)
            board(i, col) = 1;
            solutions = solveNQueens(board, col + 1, solutions);
            board(i, col) = 0;
        end
    end
end

function safe = isSafe(board, row, col)
    if any(board(row, :))
        safe = false;
        return;
    end

    for i = 1:(col - 1)
        if (row - i > 0 && board(row - i, col - i)) || (row + i <= size(board, 1) && board(row + i, col - i))
            safe = false;
            return;
        end
    end

    safe = true;
end