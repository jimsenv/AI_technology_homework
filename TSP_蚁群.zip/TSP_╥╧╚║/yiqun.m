clc;
clear;

% 给定的城市位置和城市名
locations = [116.46  39.92;
             117.2   39.13;
             121.48  31.22;
             106.54  29.59;
             91.11  29.97;
             87.68  43.77;
             106.27 38.47;
             111.65 40.82;
             108.33 22.84;
             126.63 45.75;
             125.35 43.88;
             123.38 41.8;
             114.48 38.03;
             112.53 37.87;
             101.74 36.56;
             117    36.65;
             113.65 34.76;
             118.78 32.04;
             117.27 31.86;
             120.19 30.26;
             119.3   26.08;
             115.89  28.68;
             113    28.21;
             114.31  30.52;
             113.23 23.16;
             121.5   25.05;
             110.35 20.02;
             103.73 36.03;
             108.95 34.27;
             104.06 30.67;
             106.71 26.57;
             102.73 25.04;
             114.1   22.2;
             113.33 22.13];

city_names = ["北京", "天津", "上海", "重庆", "拉萨", ...
              "乌鲁木齐", "银川", "呼和浩特", "南宁", "哈尔滨", ...
              "长春", "沈阳", "石家庄", "太原", "西宁", ...
              "济南", "郑州", "南京", "合肥", "杭州", ...
              "福州", "南昌", "长沙", "武汉", "广州", ...
              "台北", "海口", "兰州", "西安", "成都", ...
              "贵阳", "昆明", "香港", "澳门"];

% 城市数量
nCities = size(locations, 1);

% 计算所有城市之间的距离矩阵
dist = zeros(nCities, nCities);
for i = 1:nCities
    for j = 1:nCities
        dist(i, j) = sqrt((locations(i, 1) - locations(j, 1))^2 + (locations(i, 2) - locations(j, 2))^2);
    end
end

% 蚁群算法参数设置
nAnts = 50;        % 蚂蚁数量
nIter = 100;       % 迭代次数
alpha = 1;         % 信息素重要程度因子
beta = 2;          % 启发函数重要程度因子
rho = 0.5;         % 信息素挥发因子
Q = 100;           % 总信息素
bestLength = inf;  % 最短路径长度初始化为无穷大
bestTour = [];     % 最短路径

% 初始化信息素矩阵
pheromone = ones(nCities, nCities);

% 启发函数（这里启发函数为城市间的距离的倒数）
eta = 1 ./ (dist + eye(nCities));  % 对角线元素为Inf，避免城市自身与自己构成路径

% 蚁群算法主循环
for iter = 1:nIter
    % 每次迭代时，所有蚂蚁的路径和长度
    allTours = zeros(nAnts, nCities);
    allLengths = zeros(nAnts, 1);
    
    % 每只蚂蚁构造路径
    for k = 1:nAnts
        tour = zeros(1, nCities);   % 当前蚂蚁的路径
        visited = false(1, nCities); % 记录城市是否被访问过
        currentCity = randi([1, nCities]); % 随机选择一个起点城市
        tour(1) = currentCity;
        visited(currentCity) = true;
        
        % 构造路径
        for i = 2:nCities
            % 计算转移概率
            prob = zeros(1, nCities);
            for j = 1:nCities
                if ~visited(j)  % 只考虑未访问的城市
                    prob(j) = (pheromone(currentCity, j)^alpha) * (eta(currentCity, j)^beta);
                else
                    prob(j) = 0;  % 已访问的城市概率为0
                end
            end
            % 归一化概率
            prob = prob / sum(prob);
            
            % 选择下一个城市
            nextCity = rouletteWheelSelection(prob);
            tour(i) = nextCity;
            visited(nextCity) = true;
            currentCity = nextCity;
        end
        
        % 计算该路径的总长度
        totalLength = 0;
        for i = 1:nCities-1
            totalLength = totalLength + dist(tour(i), tour(i+1));
        end
        totalLength = totalLength + dist(tour(end), tour(1)); % 回到起点
        
        % 保存蚂蚁的路径和长度
        allTours(k, :) = tour;
        allLengths(k) = totalLength;
        
        % 更新最短路径
        if totalLength < bestLength
            bestLength = totalLength;
            bestTour = tour;
        end
    end
    
    % 信息素更新
    pheromone = (1 - rho) * pheromone;  % 信息素挥发
    for k = 1:nAnts
        % 根据蚂蚁路径的长度来更新信息素
        for i = 1:nCities-1
            pheromone(allTours(k, i), allTours(k, i+1)) = pheromone(allTours(k, i), allTours(k, i+1)) + Q / allLengths(k);
        end
        pheromone(allTours(k, end), allTours(k, 1)) = pheromone(allTours(k, end), allTours(k, 1)) + Q / allLengths(k); % 最后一条边
    end
    
    % 输出每一代的最优解
    fprintf('Iteration %d, Best Length = %.2f\n', iter, bestLength);
end

% 最终最短路径和对应的城市
disp('Best Tour:');
disp(city_names(bestTour));

% 绘制最短路径
figure;
hold on;

plot(locations(:, 1), locations(:, 2), 'ko', 'MarkerFaceColor', 'k');  
for i = 1:nCities
    text(locations(i, 1) + 0.2, locations(i, 2), city_names(i), 'FontSize', 8, 'Color', 'k');  
end

for i = 1:nCities-1
    plot([locations(bestTour(i), 1), locations(bestTour(i+1), 1)], ...
         [locations(bestTour(i), 2), locations(bestTour(i+1), 2)], 'b-', 'LineWidth', 1.5);
end
plot([locations(bestTour(end), 1), locations(bestTour(1), 1)], ...
     [locations(bestTour(end), 2), locations(bestTour(1), 2)], 'b-', 'LineWidth', 1.5);

hold off;
title('最短路径');
xlabel('经度');
ylabel('纬度');
axis equal;
grid on;

% 轮盘赌选择函数
function selected = rouletteWheelSelection(prob)
    % 轮盘赌选择方法
    cumsumProb = cumsum(prob);   % 累计概率
    r = rand();                  % 生成一个随机数
    selected = find(cumsumProb >= r, 1);  % 选择第一个满足条件的城市
end