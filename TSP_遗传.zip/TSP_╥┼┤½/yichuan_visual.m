clc; clear;

% 给定的城市位置和城市名
locations = [116.46  39.92;
             117.2   39.13;
             121.48  31.22;
             106.54  29.59;
             91.11  29.97;
             87.68  43.77;
             106.27 38.47;
             111.65 40.82;
             108.33 22.84;
             126.63 45.75;
             125.35 43.88;
             123.38 41.8;
             114.48 38.03;
             112.53 37.87;
             101.74 36.56;
             117    36.65;
             113.65 34.76;
             118.78 32.04;
             117.27 31.86;
             120.19 30.26;
             119.3   26.08;
             115.89  28.68;
             113    28.21;
             114.31  30.52;
             113.23 23.16;
             121.5   25.05;
             110.35 20.02;
             103.73 36.03;
             108.95 34.27;
             104.06 30.67;
             106.71 26.57;
             102.73 25.04;
             114.1   22.2;
             113.33 22.13];
         
city_names = ["北京", "天津", "上海", "重庆", "拉萨", ...
              "乌鲁木齐", "银川", "呼和浩特", "南宁", "哈尔滨", ...
              "长春", "沈阳", "石家庄", "太原", "西宁", ...
              "济南", "郑州", "南京", "合肥", "杭州", ...
              "福州", "南昌", "长沙", "武汉", "广州", ...
              "台北", "海口", "兰州", "西安", "成都", ...
              "贵阳", "昆明", "香港", "澳门"];

% 参数设置
numCities = size(locations, 1); % 城市数量
populationSize = 100; % 种群大小
generations = 10000; % 迭代次数
mutationRate = 0.1; % 变异率
crossoverRate = 0.8; % 交叉率
elitism = 0.1; % 精英策略比例

% 初始化种群
population = InitializePopulation(populationSize, numCities);

% 计算初始种群的适应度
fitness = CalculateFitness(population, locations);

% 选择最好的个体
[bestFitness, bestIndex] = min(fitness);
bestPath = population(bestIndex, :);

% 用来记录每代最优路径长度
bestFitnessHistory = zeros(generations, 1);

% 迭代更新种群
for gen = 1:generations
    % 选择父代
    parentPool = Selection(population, fitness);
    
    % 交叉生成新个体
    offspring = Crossover(parentPool, populationSize, numCities, crossoverRate);

    % 变异
    offspring = Mutation(offspring, mutationRate, numCities);
    
    % 选择精英个体
    population = ElitismSelection(population, offspring, fitness, elitism);
    
    % 计算新的适应度
    fitness = CalculateFitness(population, locations);
    
    % 选择当前最好的路径
    [currentBestFitness, currentBestIndex] = min(fitness);
    if currentBestFitness < bestFitness
        bestFitness = currentBestFitness;
        bestPath = population(currentBestIndex, :);
    end
    
    % 记录当前最优路径长度
    bestFitnessHistory(gen) = bestFitness;

    % 每100代更新图形（显示最优路径）
    if mod(gen, 100) == 0
        figure(1);
        clf;
        hold on;
        % 绘制城市点
        plot(locations(:, 1), locations(:, 2), 'ko', 'MarkerFaceColor', 'r');
        for i = 1:numCities
            text(locations(i, 1), locations(i, 2), city_names(i), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
        end

        % 绘制当前最优路径
        pathLocations = locations(bestPath, :);
        plot([pathLocations(:, 1); pathLocations(1, 1)], [pathLocations(:, 2); pathLocations(1, 2)], 'b-', 'LineWidth', 2);
        
        title(sprintf('最优路径 (代数: %d, 最短路径: %.2f)', gen, bestFitness));
        xlabel('经度');
        ylabel('纬度');
        axis equal;
        grid on;
        hold off;
        pause(0.01); % 暂停，使得图形更新
    end
end

% 最终的最短路径距离和路径
fprintf('最短路径长度： %.2f\n', bestFitness);
disp('最短路径的城市名：');
disp(city_names(bestPath));

% 可视化每代最优路径长度变化
figure;
plot(1:generations, bestFitnessHistory, 'r-', 'LineWidth', 2);
title('每代最优路径长度的变化');
xlabel('代数');
ylabel('最短路径长度');
grid on;

% 初始化种群
function population = InitializePopulation(populationSize, numCities)
    population = zeros(populationSize, numCities);
    for i = 1:populationSize
        population(i, :) = randperm(numCities);
    end
end

% 计算适应度
function fitness = CalculateFitness(population, locations)
    populationSize = size(population, 1);
    fitness = zeros(populationSize, 1);
    for i = 1:populationSize
        tour = population(i, :);
        dist = 0;
        for j = 1:length(tour)-1
            dist = dist + norm(locations(tour(j), :) - locations(tour(j+1), :));
        end
        dist = dist + norm(locations(tour(end), :) - locations(tour(1), :)); % 返回起点
        fitness(i) = dist;
    end
end

% 选择父代
function parentPool = Selection(population, fitness)
    numParents = size(population, 1);
    parentPool = zeros(numParents, size(population, 2));
    totalFitness = sum(1 ./ fitness); % 适应度的总和
    for i = 1:numParents
        randVal = rand * totalFitness;
        cumFitness = cumsum(1 ./ fitness);
        selectedIndex = find(cumFitness >= randVal, 1);
        parentPool(i, :) = population(selectedIndex, :);
    end
end

% 交叉
function offspring = Crossover(parentPool, populationSize, numCities, crossoverRate)
    offspring = zeros(populationSize, numCities);
    for i = 1:2:populationSize-1
        parent1 = parentPool(i, :);
        parent2 = parentPool(i+1, :);
        
        % 根据交叉率判断是否进行交叉
        if rand < crossoverRate
            crossoverPoint = randi([1, numCities-1]);
            offspring(i, :) = [parent1(1:crossoverPoint), setdiff(parent2, parent1(1:crossoverPoint), 'stable')];
            offspring(i+1, :) = [parent2(1:crossoverPoint), setdiff(parent1, parent2(1:crossoverPoint), 'stable')];
        else
            % 如果不交叉，则直接复制父代
            offspring(i, :) = parent1;
            offspring(i+1, :) = parent2;
        end
    end
end

% 变异
function offspring = Mutation(offspring, mutationRate, numCities)
    for i = 1:size(offspring, 1)
        if rand < mutationRate
            mutationPoints = randperm(numCities, 2);
            temp = offspring(i, mutationPoints(1));
            offspring(i, mutationPoints(1)) = offspring(i, mutationPoints(2));
            offspring(i, mutationPoints(2)) = temp;
        end
    end
end

% 精英策略选择
function population = ElitismSelection(population, offspring, fitness, elitism)
    eliteCount = round(elitism * size(population, 1));
    [~, eliteIndexes] = sort(fitness);
    elitePopulation = population(eliteIndexes(1:eliteCount), :);
    nonElitePopulation = offspring;
    population = [elitePopulation; nonElitePopulation(1:end-eliteCount, :)];
end
