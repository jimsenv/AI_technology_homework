clc; clear;

% 定义10个城市的坐标和名称
locations = [
116.46  39.92
117.2  39.13
121.48  31.22
106.54  29.59
91.11  29.97
87.68  43.77
106.27  38.47
111.65  40.82
108.33  22.84
126.63  45.75];

city_names=["北京","天津","上海","重庆","拉萨",...
    "乌鲁木齐","银川","呼和浩特","南宁","哈尔滨"];

% 计算欧氏距离矩阵
n = size(locations, 1);  % 城市数量
dist = zeros(n, n);  % 初始化距离矩阵
for p = 1:n
    for q = 1:n
        if p ~= q
            dist(p, q) = sqrt((locations(p, 1) - locations(q, 1))^2 + ...
                              (locations(p, 2) - locations(q, 2))^2);
        end
    end
end

% 获取所有城市的排列
permutations = perms(1:n);  

% 初始化最短路径的距离
min_distance = inf;
min_path = zeros(1,n);

% 遍历所有路径并计算总距离
for p = 1:size(permutations, 1)
    path = permutations(p, :);  % 当前路径
    total_distance = 0;  % 当前路径的总距离
    
    % 计算当前路径的总距离
    for q = 1:n-1
        total_distance = total_distance + dist(path(q), path(q+1));
    end
    % 计算从最后一个城市回到第一个城市的距离
    total_distance = total_distance + dist(path(n), path(1));
    
    % 更新最短路径
    if total_distance < min_distance
        min_distance = total_distance;
        min_path = path;
    end
end

% 输出结果
disp('最短路径顺序:');
disp(city_names(min_path));
disp('最短路径总距离:');
disp(min_distance);

% 可视化
figure;
hold on;
% 绘制城市点
plot(locations(:, 1), locations(:, 2), 'ko', 'MarkerFaceColor', 'r');
for i = 1:n
    text(locations(i, 1), locations(i, 2), city_names(i), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
end

% 绘制最短路径
pathLocations = locations(min_path, :);
plot([pathLocations(:, 1); pathLocations(1, 1)], [pathLocations(:, 2); pathLocations(1, 2)], 'b-', 'LineWidth', 2);

title('最短路径');
xlabel('经度');
ylabel('纬度');
axis equal;
grid on;
hold off;