function [shortestPath, distance] = dijkstra(adjMatrix, startNode, endNode)   
  
    numNodes = size(adjMatrix, 1); 
    minDistance = inf(1, numNodes);
    minDistance(startNode) = 0;
    fatherNodes = zeros(1, numNodes);
    fatherNodes(startNode) = startNode;

    used = []; 
    doko = startNode;

    while length(used) < numNodes

        for p = 1:numNodes
            if ~ismember(p, used) 
                if minDistance(p) > (minDistance(doko) + adjMatrix(doko, p)) && adjMatrix(doko, p) < inf
                    minDistance(p) = (minDistance(doko) + adjMatrix(doko, p));
                    fatherNodes(p) = doko;
                end
            end
        end

        koko = 0;
        kore = inf;

        for p = 1:numNodes
            if ~ismember(p, used) 
                if kore > minDistance(p)
                    kore = minDistance(p);
                    koko = p;
                end
            end
        end

        if koko == 0 
            break;
        end

        used(end + 1) = koko;
        doko = koko;
    end
      
    distance = minDistance(endNode);
    if distance == inf
        shortestPath = []; 
        return;
    end
    
    shortestPath(1) = endNode;
    
    temp = 1;
    while shortestPath(temp) ~= startNode
        shortestPath(temp + 1) = fatherNodes(shortestPath(temp));
        temp = temp + 1;
    end

    shortestPath = shortestPath(length(shortestPath):-1:1); 

end