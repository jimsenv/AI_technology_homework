clc; clear all;

adjMatrix = [0, 2, inf, 7, inf, inf, inf, 1, inf, inf  ;
 2, 0, 5, inf, inf, 3, inf, inf, 4, inf ;
 inf, 5, 0, inf, 8, inf, 1, inf, inf, inf  ;
 7, inf, inf, 0, 6, inf, inf, inf, inf, 2 ;
 inf, inf, 8, 6, 0, inf, inf, inf, inf, inf  ;
 inf, 3, inf, inf, inf, 0, inf, 9, inf, inf ;
 inf, inf, 1, inf, inf, inf, 0, inf, inf, 7 ;
 1, inf, inf, inf, inf, 9, inf, 0, inf, inf ;
 inf, 4, inf, inf, inf, inf, inf, inf, 0, inf  ;
 inf, inf, inf, 2, inf, inf, 7, inf, inf, 0] ;

startNode = 1;  
endNode = 10; 

[shortestPath, distance] = dijkstra(adjMatrix, startNode, endNode);  
  
disp(['最短路径: ', num2str(shortestPath)]);  
disp(['最短距离: ', num2str(distance)]);