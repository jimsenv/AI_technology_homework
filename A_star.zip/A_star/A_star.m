function [shortestPath, distance] = A_star(Matrix, startNode, endNode)
    
    openSet = []; 
    closedSet = []; 
    gScore = inf(size(Matrix)); 
    gScore(startNode(1), startNode(2)) = 0;
    fScore = inf(size(Matrix)); 
    fScore(startNode(1), startNode(2)) = manhattanDistance(startNode, endNode);
    
    openSet = [openSet; startNode]; 
    cameFrom = zeros(size(Matrix)); 

    while ~isempty(openSet)
        
        [~, idx] = min(fScore(sub2ind(size(fScore), openSet(:,1), openSet(:,2))));
        current = openSet(idx, :);
        
        if all(current == endNode)
            [shortestPath, distance] = reconstructPath(cameFrom, current, size(Matrix));
            return;
        end
        
        openSet(idx, :) = [];
        closedSet = [closedSet; current];
        
        neighbors = getNeighbors(current, size(Matrix));
        for i = 1:size(neighbors, 1)
            neighbor = neighbors(i, :);
            if ismember(neighbor, closedSet, 'rows') || Matrix(neighbor(1), neighbor(2)) == 1
                continue; 
            end
            
            tentative_gScore = gScore(current(1), current(2)) + 1; 
            
            if ~ismember(neighbor, openSet, 'rows')
                openSet = [openSet; neighbor]; 
            elseif tentative_gScore >= gScore(neighbor(1), neighbor(2))
                continue; 
            end
            
            cameFrom(neighbor(1), neighbor(2)) = sub2ind(size(Matrix), current(1), current(2));
            gScore(neighbor(1), neighbor(2)) = tentative_gScore;
            fScore(neighbor(1), neighbor(2)) = gScore(neighbor(1), neighbor(2)) + manhattanDistance(neighbor, endNode);
        end
    end
    
    shortestPath = zeros(size(Matrix));
    distance = inf;
end

function distance = manhattanDistance(nodeA, nodeB)
    distance = abs(nodeA(1) - nodeB(1)) + abs(nodeA(2) - nodeB(2));
end

function neighbors = getNeighbors(node, matrixSize)
    directions = [0 1; 1 0; 0 -1; -1 0]; 
    neighbors = [];
    for d = 1:size(directions, 1)
        neighbor = node + directions(d, :);
        if all(neighbor > 0) && neighbor(1) <= matrixSize(1) && neighbor(2) <= matrixSize(2)
            neighbors = [neighbors; neighbor];
        end
    end
end

function [path, distance] = reconstructPath(cameFrom, current, matrixSize)
    path = zeros(matrixSize);
    distance = 0;
    
    while cameFrom(current(1), current(2)) > 0
        path(current(1), current(2)) = 1; 
        distance = distance + 1; 

        currentIndex = cameFrom(current(1), current(2));
        [current(1), current(2)] = ind2sub(size(cameFrom), currentIndex);
    end
    
    path(current(1), current(2)) = 1; 
end

