clc; clear all;

Matrix=[ 0 0 0 0 0 1 1 1 0 
    0 0 0 0 0 0 0 0 1
    1 1 1 0 1 0 1 0 0
    0 0 0 0 0 0 0 0 0
    1 1 1 0 0 1 1 0 0
    0 1 0 0 0 0 1 1 1 
    0 0 1 0 1 0 0 0 0
    0 0 1 1 1 1 1 1 0
    0 0 0 0 0 0 0 0 0 ];
startNode=[1,1];
endNode=[6,1];

[shortestPath,distance]=A_star(Matrix,startNode,endNode);

disp('最短路径为:');
disp(shortestPath);
disp(['最短距离: ', num2str(distance)]);